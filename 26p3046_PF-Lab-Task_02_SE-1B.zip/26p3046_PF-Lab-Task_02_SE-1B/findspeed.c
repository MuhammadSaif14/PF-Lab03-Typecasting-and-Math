#include <stdio.h>
#include <math.h>
int main(){
	
	float time, distance, avg_speed;

	printf("Enter the time travelled (in hours): ");
	scanf("%f", &time);
	printf("Enter the distance travelled (in kilometers): ");
	scanf("%f", &distance);

	avg_speed = distance/time; 

	printf("The average speed is: %f", avg_speed);

	return 0;
}
