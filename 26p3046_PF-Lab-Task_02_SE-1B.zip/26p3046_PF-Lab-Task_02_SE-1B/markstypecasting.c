#include <stdio.h>
int main(){

	int sub1, sub2, sub3, total;
	float average;

	printf("Input Subject 1 marks: ");
	scanf("%d", &sub1);
	printf("Input Subject 2 marks: ");
	scanf("%d", &sub2);
	printf("Input Subject 3 marks: ");
	scanf("%d", &sub3);
	
	total = sub1+sub2+sub3;

	average = (float) total/3;

	printf("total: %d \n", total);
	printf("Average: %f", average);

	return 0;
}