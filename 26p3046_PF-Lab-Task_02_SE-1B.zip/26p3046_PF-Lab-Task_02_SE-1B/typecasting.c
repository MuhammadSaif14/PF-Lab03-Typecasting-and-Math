#include <stdio.h>
int main(){

	int a,b; 
	float value1, value2, value3;
	
	printf("Enter the value a: ");
	scanf("%d", &a);
	printf("Enter the value b: ");
	scanf("%d", &b);

	value1 = a/b;
	value2 = (float) a/b;
	value3 = (float) (a/b);
	
	printf("a/b = %f \n", value1);
	printf("(float) a/b = %f \n", value2);
	printf("(float) (a/b) = %f \n", value3);



	return 0;
}