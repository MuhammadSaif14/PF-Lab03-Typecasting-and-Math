#include <stdio.h>
int main(){
	
	double tax_rate, salary, net_income, tax_amount;

	printf("Enter the Tax rate (0-100): ");
	scanf("%lf", &tax_rate);
	printf("Enter the salary: ");
	scanf("%lf", &salary);

	tax_amount = salary * (tax_rate/100);
	net_income = salary - tax_amount;
 
	printf("The Tax amount is: Rs. %.2lf \n", tax_amount);
	printf("The net income is: Rs. %.2lf ", net_income); 

	return 0;
}