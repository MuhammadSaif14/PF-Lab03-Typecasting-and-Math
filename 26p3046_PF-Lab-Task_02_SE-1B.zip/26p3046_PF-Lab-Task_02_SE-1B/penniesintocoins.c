#include <stdio.h>
int main(){
	
	int pennies, quarters, dimes, nickels;
	pennies = 368;

	printf("\nAli have %d pennies \n\n", pennies);

	quarters = pennies / 25;
	pennies = pennies % 25;
	
	dimes = pennies / 10;
	pennies = pennies % 10;

	nickels = pennies / 5;
	pennies = pennies % 5;
	
	printf("Quarters: %d \n", quarters);
	printf("Dimes: %d \n", dimes);
	printf("Nickels: %d \n", nickels);
	printf("Pennies: %d \n\n", pennies);

	int total = quarters + dimes + nickels + pennies;

	printf("Now Ali has %d coins", total);


	return 0;
}