#include <stdio.h>
#include <math.h>
int main(){
	
	int a, b, c, discriminant, x1, x2;
	
	printf("Enter the value a: ");
	scanf("%d", &a);
	printf("Enter the value b: ");
	scanf("%d", &b);
	printf("Enter the value c: ");
	scanf("%d", &c);

	x1 = (-b + sqrt(b*b - 4*a*c))/ 2*a;
	x2 = (-b - sqrt(b*b - 4*a*c))/ 2*a;

	printf("Solving the equation gives the roots: \nx1 = %d \nx2 = %d", x1, x2);


	return 0;
}