#include <stdio.h>
int main(){

	int Num1, Num2, temporary;
	
	printf("Enter the first number: ");
	scanf("%d", &Num1);
	printf("Enter the second number: ");
	scanf("%d", &Num2);

	temporary = Num1;
	Num1 = Num2;
	Num2 = temporary;

	printf("After swapping: Number First = %d  & Number second = %d \n", Num1, Num2);

	return 0;
}