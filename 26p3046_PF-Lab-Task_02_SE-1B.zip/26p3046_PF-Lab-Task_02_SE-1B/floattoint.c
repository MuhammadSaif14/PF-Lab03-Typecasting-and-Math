#include <stdio.h>
int main(){
	
	float original_value, difference;
	int converted_integer;	

	printf("Enter the value between -1000 to 1000: ");
	scanf("%f", &original_value);

	converted_integer = (int) original_value;

	difference = original_value - converted_integer;

	printf("Original value: %f \n", original_value);
	printf("Converted integer: %d \n", converted_integer);
	printf("Difference: %f", difference);

	return 0;
}